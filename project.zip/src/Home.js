import React from 'react'
import Footer from './component/footer'
// import Carousel from './component/carousel'
import Banners from './component/Banner'

const Home = () => {
  return (
    <>
    <Banners/>
    {/* <Carousel /> */}
    <Footer />
    </>
  )
}

export default Home